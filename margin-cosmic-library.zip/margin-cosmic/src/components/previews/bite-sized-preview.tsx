'use client';

import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import { ArrowLeft, ArrowRight, BookOpen, Clock3, Play, Sparkles } from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/lib/utils';

export type BookTrailer = {
  id: string;
  title: string;
  author: string;
  hook: string;
  mood: string;
  durationSeconds: number;
  coverUrl: string;
  accent: 'violet' | 'teal' | 'gold';
};

type Props = { trailers: BookTrailer[]; onOpenBook?: (bookId: string) => void; className?: string };
const accentClasses = {
  violet: 'from-violet-950/95 via-indigo-950/80 to-cosmic-void border-violet-400/30',
  teal: 'from-teal-950/90 via-cyan-950/70 to-cosmic-void border-teal-300/30',
  gold: 'from-amber-950/90 via-orange-950/70 to-cosmic-void border-amber-300/30'
} as const;

export function BiteSizedPreview({ trailers, onOpenBook, className }: Props) {
  const [index, setIndex] = useState(0);
  const reduceMotion = useReducedMotion();
  if (!trailers.length) return <p className="rounded-2xl border border-cosmic-border p-6 text-cosmic-muted">New story trailers are drifting in soon.</p>;
  const active = trailers[index % trailers.length]!;
  const step = (delta: number) => setIndex((current) => (current + delta + trailers.length) % trailers.length);

  return (
    <section className={cn('w-full', className)} aria-label="Bite-sized book previews">
      <div className="mb-4 flex items-end justify-between gap-3">
        <div><p className="text-xs font-semibold uppercase tracking-[.24em] text-cosmic-gold">A story in 30 seconds</p><h2 className="mt-1 font-display text-2xl text-cosmic-stardust sm:text-3xl">Tiny portals, big worlds.</h2></div>
        <div className="flex gap-2">
          <button onClick={() => step(-1)} aria-label="Previous preview" className="rounded-full border border-cosmic-border p-2 text-cosmic-stardust hover:border-cosmic-violet"><ArrowLeft size={18}/></button>
          <button onClick={() => step(1)} aria-label="Next preview" className="rounded-full border border-cosmic-border p-2 text-cosmic-stardust hover:border-cosmic-violet"><ArrowRight size={18}/></button>
        </div>
      </div>
      <div className="mx-auto max-w-5xl overflow-hidden rounded-[1.75rem]">
        <AnimatePresence mode="wait">
          <motion.article key={active.id} initial={reduceMotion ? false : { opacity: 0, x: 28, scale: .985 }} animate={{ opacity: 1, x: 0, scale: 1 }} exit={reduceMotion ? undefined : { opacity: 0, x: -24, scale: .99 }} transition={{ duration: .32, ease: 'easeOut' }}
            className={cn('relative grid min-h-[390px] overflow-hidden rounded-[1.75rem] border bg-gradient-to-br md:grid-cols-[.9fr_1.1fr]', accentClasses[active.accent])}>
            <div className="absolute inset-0 opacity-20" aria-hidden="true" style={{ backgroundImage: 'radial-gradient(circle at 20% 20%, white 0 1px, transparent 1.5px), radial-gradient(circle at 75% 55%, white 0 1px, transparent 1.5px)', backgroundSize: '47px 47px, 71px 71px' }}/>
            <div className="relative flex items-center justify-center p-8 md:p-10">
              {/* Use curated, licensed cover art. The cover is decorative; the text remains accessible. */}
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={active.coverUrl} alt={`Cover art for ${active.title}`} className="max-h-[300px] w-auto rounded-xl object-cover shadow-2xl shadow-black/50 transition-transform duration-500 hover:-rotate-2 hover:scale-[1.03]" />
              <span className="absolute bottom-5 left-5 inline-flex items-center gap-2 rounded-full border border-white/15 bg-black/35 px-3 py-1.5 text-xs text-white backdrop-blur"><Clock3 size={13}/>{active.durationSeconds}s preview</span>
            </div>
            <div className="relative flex flex-col justify-center p-7 md:p-10">
              <span className="mb-4 inline-flex w-fit items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3 py-1 text-xs text-cosmic-stardust"><Sparkles size={13}/>{active.mood}</span>
              <p className="mb-3 text-xs uppercase tracking-[.2em] text-white/55">A little glimpse into</p>
              <h3 className="font-display text-4xl leading-tight text-white sm:text-5xl">{active.title}</h3>
              <p className="mt-2 text-sm text-white/65">by {active.author}</p>
              <p className="mt-6 max-w-md text-lg leading-relaxed text-white/85">“{active.hook}”</p>
              <div className="mt-8 flex flex-wrap gap-3">
                <button onClick={() => onOpenBook?.(active.id)} className="inline-flex items-center gap-2 rounded-full bg-cosmic-teal px-5 py-3 text-sm font-bold text-cosmic-void transition hover:bg-cosmic-aqua focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"><BookOpen size={17}/>Step inside</button>
                <span className="inline-flex items-center gap-2 rounded-full border border-white/20 px-4 py-3 text-sm text-white/75"><Play size={15}/>Trailer card</span>
              </div>
            </div>
          </motion.article>
        </AnimatePresence>
      </div>
      <div className="mt-3 flex justify-center gap-1.5" aria-label={`Preview ${index + 1} of ${trailers.length}`}>
        {trailers.map((trailer, i) => <button key={trailer.id} onClick={() => setIndex(i)} aria-label={`Show preview ${i + 1}: ${trailer.title}`} aria-current={i === index ? 'true' : undefined} className={cn('h-1.5 rounded-full transition-all', i === index ? 'w-8 bg-cosmic-teal' : 'w-1.5 bg-cosmic-border hover:bg-cosmic-muted')}/>)}
      </div>
    </section>
  );
}
