'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { BookOpen, ChevronLeft, ChevronRight, Highlighter, LoaderCircle, MessageCircle, Minus, Moon, Plus, Send, SidebarClose, SidebarOpen } from 'lucide-react';
import { cn } from '@/lib/utils';

type PublicAnnotation = { id: string; displayName: string; pageNumber: number; body: string; selectedText?: string | null; createdAt: string };
type Props = { bookId: string; title: string; initialAnnotations?: PublicAnnotation[]; className?: string };

/**
 * PDF.js reader shell. It fetches a short-lived URL from the server route, renders a page to canvas,
 * and loads public annotations separately. Annotation creation should be wired to an authenticated
 * server endpoint that validates input and ownership; never trust a client-supplied user ID.
 */
export function SocialMarginReader({ bookId, title, initialAnnotations = [], className }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [pageCount, setPageCount] = useState(0);
  const [pageNumber, setPageNumber] = useState(1);
  const [scale, setScale] = useState(1.15);
  const [darkPage, setDarkPage] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [annotations, setAnnotations] = useState(initialAnnotations);
  const [draft, setDraft] = useState('');
  const [noteError, setNoteError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    fetch(`/api/books/${encodeURIComponent(bookId)}/pdf-url`, { credentials: 'same-origin', cache: 'no-store' })
      .then(async (response) => {
        if (!response.ok) throw new Error(response.status === 401 ? 'Sign in to open this book.' : 'This book is not available right now.');
        return response.json() as Promise<{ url: string }>;
      })
      .then(({ url }) => { if (alive) setPdfUrl(url); })
      .catch((err: unknown) => { if (alive) setError(err instanceof Error ? err.message : 'Could not load the book.'); })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
  }, [bookId]);

  useEffect(() => {
    if (!pdfUrl || !canvasRef.current) return;
    let cancelled = false;
    let loadingTask: { promise: Promise<{ numPages: number; getPage: (page: number) => Promise<any>; destroy: () => Promise<void> }>; destroy: () => Promise<void> } | undefined;
    async function renderPage() {
      try {
        setLoading(true); setError(null);
        const pdfjs = await import('pdfjs-dist');
        // The worker is served locally to avoid a third-party CDN dependency.
        pdfjs.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.mjs';
        loadingTask = pdfjs.getDocument({ url: pdfUrl!, withCredentials: false }) as typeof loadingTask;
        const pdf = await loadingTask.promise;
        if (cancelled) return;
        setPageCount(pdf.numPages);
        const page = await pdf.getPage(pageNumber);
        if (cancelled || !canvasRef.current) return;
        const viewport = page.getViewport({ scale });
        const canvas = canvasRef.current;
        const context = canvas.getContext('2d');
        if (!context) throw new Error('Canvas is unavailable in this browser.');
        const dpr = window.devicePixelRatio || 1;
        canvas.width = Math.floor(viewport.width * dpr);
        canvas.height = Math.floor(viewport.height * dpr);
        canvas.style.width = `${viewport.width}px`;
        canvas.style.height = `${viewport.height}px`;
        await page.render({ canvasContext: context, viewport, transform: dpr !== 1 ? [dpr, 0, 0, dpr, 0, 0] : undefined }).promise;
      } catch (err) {
        if (!cancelled) setError(err instanceof Error ? err.message : 'Unable to render this PDF.');
      } finally { if (!cancelled) setLoading(false); }
    }
    void renderPage();
    return () => { cancelled = true; void loadingTask?.destroy(); };
  }, [pdfUrl, pageNumber, scale]);

  const changePage = useCallback((next: number) => setPageNumber(Math.min(Math.max(1, next), Math.max(pageCount, 1))), [pageCount]);
  const submitNote = async () => {
    const body = draft.trim();
    if (!body) { setNoteError('Write a thought before posting.'); return; }
    // UI-only optimistic preview is intentionally not persisted here; connect to a protected POST endpoint.
    setAnnotations((current) => [{ id: `local-${Date.now()}`, displayName: 'You', pageNumber, body, createdAt: new Date().toISOString() }, ...current]);
    setDraft(''); setNoteError('Preview only: connect the authenticated annotation POST route to publish this note.');
  };

  return (
    <section ref={containerRef} className={cn('overflow-hidden rounded-2xl border border-cosmic-border bg-cosmic-midnight text-cosmic-stardust', className)} aria-label={`PDF reader for ${title}`}>
      <header className="flex flex-wrap items-center justify-between gap-3 border-b border-cosmic-border bg-cosmic-surface/80 px-4 py-3">
        <div className="flex min-w-0 items-center gap-3"><span className="rounded-xl bg-cosmic-violet/15 p-2 text-cosmic-violet"><BookOpen size={19}/></span><div className="min-w-0"><h2 className="truncate text-sm font-semibold">{title}</h2><p className="text-xs text-cosmic-muted">The Reading Room · Social Margin</p></div></div>
        <div className="flex items-center gap-1.5">
          <button onClick={() => setScale((v) => Math.max(.65, Math.round((v - .1) * 100) / 100))} aria-label="Zoom out" className="rounded-lg p-2 hover:bg-cosmic-raised"><Minus size={16}/></button><span className="min-w-12 text-center text-xs tabular-nums text-cosmic-muted">{Math.round(scale * 100)}%</span><button onClick={() => setScale((v) => Math.min(2.25, Math.round((v + .1) * 100) / 100))} aria-label="Zoom in" className="rounded-lg p-2 hover:bg-cosmic-raised"><Plus size={16}/></button>
          <button onClick={() => setDarkPage((v) => !v)} aria-pressed={darkPage} aria-label="Toggle reading contrast" className={cn('rounded-lg p-2 hover:bg-cosmic-raised', darkPage && 'text-cosmic-teal')}><Moon size={16}/></button>
          <button onClick={() => setSidebarOpen((v) => !v)} aria-expanded={sidebarOpen} aria-label={sidebarOpen ? 'Hide Social Margin' : 'Show Social Margin'} className="rounded-lg p-2 hover:bg-cosmic-raised">{sidebarOpen ? <SidebarClose size={17}/> : <SidebarOpen size={17}/>}</button>
        </div>
      </header>
      <div className={cn('grid min-h-[600px]', sidebarOpen ? 'lg:grid-cols-[minmax(0,1fr)_310px]' : 'grid-cols-1')}>
        <div className={cn('relative flex min-h-[520px] flex-col items-center overflow-auto p-4 sm:p-8', darkPage ? 'bg-[#10101a]' : 'bg-[#1b1b2e]')}>
          {loading && <div className="absolute inset-0 z-10 flex items-center justify-center bg-cosmic-void/70"><LoaderCircle className="animate-spin text-cosmic-teal"/><span className="ml-2 text-sm">Opening your book…</span></div>}
          {error ? <div role="alert" className="m-auto max-w-sm rounded-xl border border-cosmic-danger/30 bg-cosmic-danger/5 p-5 text-center text-sm text-cosmic-stardust">{error}<p className="mt-2 text-xs text-cosmic-muted">Check your connection and book access, then try again.</p></div> : <canvas ref={canvasRef} className={cn('max-w-full shadow-2xl shadow-black/30', darkPage && 'brightness-[.82] sepia-[.08]')} aria-label={`Page ${pageNumber} of ${pageCount || '…'}`}/>}
          <div className="sticky bottom-0 mt-auto flex items-center gap-4 rounded-full border border-white/10 bg-cosmic-void/90 px-4 py-2 text-sm backdrop-blur"><button disabled={pageNumber <= 1} onClick={() => changePage(pageNumber - 1)} aria-label="Previous page" className="disabled:opacity-30"><ChevronLeft size={18}/></button><span className="min-w-24 text-center text-xs text-cosmic-muted">Page {pageNumber}{pageCount ? ` / ${pageCount}` : ''}</span><button disabled={!!pageCount && pageNumber >= pageCount} onClick={() => changePage(pageNumber + 1)} aria-label="Next page" className="disabled:opacity-30"><ChevronRight size={18}/></button></div>
        </div>
        {sidebarOpen && <aside className="flex min-h-[520px] flex-col border-t border-cosmic-border bg-cosmic-deep lg:border-l lg:border-t-0" aria-label="Social Margin annotations">
          <div className="border-b border-cosmic-border p-4"><div className="flex items-center gap-2"><MessageCircle size={17} className="text-cosmic-teal"/><h3 className="font-display text-xl">Social Margin</h3></div><p className="mt-1 text-xs leading-relaxed text-cosmic-muted">Thoughts from people in this story. Public notes only.</p></div>
          <div className="flex-1 space-y-3 overflow-y-auto p-3">{annotations.filter((note) => note.pageNumber === pageNumber).length === 0 && <div className="rounded-xl border border-dashed border-cosmic-border p-4 text-center"><Highlighter className="mx-auto mb-2 text-cosmic-violet" size={20}/><p className="text-sm text-cosmic-stardust">A quiet page.</p><p className="mt-1 text-xs text-cosmic-muted">No public notes on this page yet.</p></div>}
            {annotations.filter((note) => note.pageNumber === pageNumber).map((note) => <article key={note.id} className="rounded-xl border border-cosmic-border bg-cosmic-surface p-3"><div className="mb-2 flex items-center justify-between gap-2"><span className="text-xs font-semibold text-cosmic-teal">{note.displayName}</span><time className="text-[10px] text-cosmic-muted">{new Date(note.createdAt).toLocaleDateString()}</time></div>{note.selectedText && <blockquote className="mb-2 border-l-2 border-cosmic-violet pl-2 text-xs italic text-cosmic-muted">{note.selectedText}</blockquote>}<p className="whitespace-pre-wrap text-sm leading-relaxed text-cosmic-stardust">{note.body}</p></article>)}
          </div>
          <form className="border-t border-cosmic-border p-3" onSubmit={(event) => { event.preventDefault(); void submitNote(); }}><label htmlFor="margin-note" className="mb-2 block text-xs font-medium text-cosmic-muted">Leave a thought on page {pageNumber}</label><textarea id="margin-note" value={draft} onChange={(e) => setDraft(e.target.value)} maxLength={5000} rows={3} placeholder="A thought worth leaving in the margin…" className="w-full resize-y rounded-xl border border-cosmic-border bg-cosmic-midnight p-3 text-sm outline-none placeholder:text-cosmic-muted/60 focus:border-cosmic-violet"/><div className="mt-2 flex items-center justify-between gap-2"><p aria-live="polite" className="text-[10px] text-cosmic-muted">Public notes should never contain private information.</p><button type="submit" className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-cosmic-violet px-3 py-2 text-xs font-semibold text-white hover:bg-cosmic-nebula"><Send size={13}/>Post</button></div>{noteError && <p role="status" className="mt-2 text-xs text-cosmic-gold">{noteError}</p>}</form>
        </aside>}
      </div>
    </section>
  );
}
