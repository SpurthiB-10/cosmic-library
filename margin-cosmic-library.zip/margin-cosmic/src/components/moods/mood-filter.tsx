'use client';

import { motion } from 'motion/react';
import { CloudRain, Flame, Heart, MoonStar, Sparkles, Brain, Compass, type LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

export const READING_MOODS = [
  { id: 'rainy-midnight', label: 'Rainy midnight', hint: 'Soft, wistful worlds', icon: CloudRain },
  { id: 'ambition', label: 'Fuel my ambition', hint: 'Ideas that move you', icon: Flame },
  { id: 'comfort', label: 'A little comfort', hint: 'Warm and familiar', icon: Heart },
  { id: 'mind-bending', label: 'Bend my mind', hint: 'Strange, brilliant ideas', icon: Brain },
  { id: 'wonder', label: 'Cosmic wonder', hint: 'Worlds beyond this one', icon: Sparkles },
  { id: 'wander', label: 'Let me wander', hint: 'A beautiful detour', icon: Compass },
  { id: 'after-dark', label: 'After dark', hint: 'Mystery and shadows', icon: MoonStar }
] as const satisfies ReadonlyArray<{ id: string; label: string; hint: string; icon: LucideIcon }>;

export type ReadingMoodId = typeof READING_MOODS[number]['id'];

type MoodFilterProps = {
  value: ReadingMoodId | 'all';
  onChange: (mood: ReadingMoodId | 'all') => void;
  className?: string;
};

export function MoodFilter({ value, onChange, className }: MoodFilterProps) {
  return (
    <section aria-label="Discover books by mood" className={cn('w-full', className)}>
      <div className="mb-3 flex items-end justify-between gap-3">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[.24em] text-cosmic-teal">Tune your universe</p>
          <h2 className="mt-1 font-display text-2xl text-cosmic-stardust sm:text-3xl">What are we feeling?</h2>
        </div>
        <button onClick={() => onChange('all')} className="text-sm text-cosmic-muted transition hover:text-cosmic-teal" aria-pressed={value === 'all'}>
          Clear mood
        </button>
      </div>
      <div className="flex gap-3 overflow-x-auto pb-3 [scrollbar-width:thin]" role="group" aria-label="Mood choices">
        {READING_MOODS.map((mood) => {
          const Icon = mood.icon;
          const selected = value === mood.id;
          return (
            <motion.button key={mood.id} type="button" whileTap={{ scale: 0.97 }} onClick={() => onChange(selected ? 'all' : mood.id)}
              aria-pressed={selected}
              className={cn('group relative min-w-[172px] rounded-2xl border p-4 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cosmic-teal',
                selected ? 'border-cosmic-teal/70 bg-cosmic-teal/10 shadow-glow-teal' : 'border-cosmic-border bg-cosmic-surface/80 hover:border-cosmic-violet/70 hover:bg-cosmic-raised')}>
              <span className={cn('mb-5 flex h-9 w-9 items-center justify-center rounded-xl', selected ? 'bg-cosmic-teal text-cosmic-void' : 'bg-cosmic-raised text-cosmic-violet')}>
                <Icon size={18} aria-hidden="true" />
              </span>
              <span className="block text-sm font-semibold text-cosmic-stardust">{mood.label}</span>
              <span className="mt-1 block text-xs text-cosmic-muted">{mood.hint}</span>
              {selected && <motion.span layoutId="mood-indicator" className="absolute right-3 top-3 h-2 w-2 rounded-full bg-cosmic-teal shadow-glow-teal" />}
            </motion.button>
          );
        })}
      </div>
    </section>
  );
}
