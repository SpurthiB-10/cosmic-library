import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db/prisma';
import { getAuthenticatedUser } from '@/lib/auth/supabase-server';
import { createPdfReadUrl } from '@/lib/storage/s3';
import { BookVisibility } from '@prisma/client';

export const runtime = 'nodejs';

export async function GET(_request: Request, context: { params: Promise<{ bookId: string }> }) {
  const { bookId } = await context.params;
  const user = await getAuthenticatedUser();
  const book = await prisma.book.findUnique({
    where: { id: bookId },
    select: { id: true, storageKey: true, visibility: true, isPublished: true, ownerId: true }
  });

  if (!book || !book.isPublished || !book.storageKey) {
    return NextResponse.json({ error: 'Book not found.' }, { status: 404 });
  }
  const publiclyReadable = book.visibility === BookVisibility.PUBLIC_DOMAIN || book.visibility === BookVisibility.LICENSED;
  if (!publiclyReadable) {
    if (!user) return NextResponse.json({ error: 'Sign in to access this book.' }, { status: 401 });
    const appUser = await prisma.user.findUnique({ where: { authUserId: user.id }, select: { id: true } });
    if (!appUser || book.ownerId !== appUser.id) {
      return NextResponse.json({ error: 'You do not have access to this book.' }, { status: 403 });
    }
  }
  try {
    const url = await createPdfReadUrl(book.storageKey);
    return NextResponse.json({ url, expiresIn: 300 }, { headers: { 'Cache-Control': 'private, no-store' } });
  } catch {
    return NextResponse.json({ error: 'PDF delivery is temporarily unavailable.' }, { status: 503 });
  }
}
