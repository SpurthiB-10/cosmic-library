import type { Metadata } from 'next';
import { Cormorant_Garamond, Inter } from 'next/font/google';
import './globals.css';

const cormorant = Cormorant_Garamond({ subsets: ['latin'], variable: '--font-cormorant', weight: ['400', '500', '600', '700'], display: 'swap' });
const inter = Inter({ subsets: ['latin'], variable: '--font-inter', display: 'swap' });

export const metadata: Metadata = {
  title: { default: 'MARGIN — The Dreamer’s Archive', template: '%s · MARGIN' },
  description: 'Find a story that feels like you. A cosmic reading universe for curious minds.',
  applicationName: 'MARGIN',
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3000'),
  robots: { index: false, follow: false }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en" className={`${cormorant.variable} ${inter.variable}`}><body className="font-sans antialiased"><a href="#main-content" className="sr-only z-50 rounded bg-cosmic-teal p-3 text-cosmic-void focus:not-sr-only focus:fixed focus:left-3 focus:top-3">Skip to content</a>{children}</body></html>;
}
