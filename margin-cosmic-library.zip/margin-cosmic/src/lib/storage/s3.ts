import { S3Client, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

const endpoint = process.env.S3_ENDPOINT;
const bucket = process.env.S3_BUCKET;
if (!endpoint || !bucket || !process.env.S3_ACCESS_KEY_ID || !process.env.S3_SECRET_ACCESS_KEY) {
  // Fail at call time so the public catalog can still render without storage configured.
}

const s3 = new S3Client({
  region: process.env.S3_REGION ?? 'auto',
  endpoint,
  forcePathStyle: process.env.S3_FORCE_PATH_STYLE === 'true',
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY_ID ?? '',
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY ?? ''
  }
});

export async function createPdfReadUrl(storageKey: string): Promise<string> {
  if (!bucket || !process.env.S3_ACCESS_KEY_ID || !process.env.S3_SECRET_ACCESS_KEY) {
    throw new Error('PDF storage is not configured.');
  }
  return getSignedUrl(s3, new GetObjectCommand({ Bucket: bucket, Key: storageKey }), { expiresIn: 300 });
}
