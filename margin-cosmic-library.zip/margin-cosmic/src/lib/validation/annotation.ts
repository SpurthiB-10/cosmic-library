import { z } from 'zod';

export const annotationInputSchema = z.object({
  bookId: z.string().min(1).max(100),
  pageNumber: z.number().int().min(1).max(100_000),
  body: z.string().trim().min(1).max(5000),
  selectedText: z.string().max(2000).optional(),
  kind: z.enum(['NOTE', 'HIGHLIGHT', 'QUESTION']).default('NOTE'),
  visibility: z.enum(['PRIVATE', 'PUBLIC']).default('PRIVATE')
});
export type AnnotationInput = z.infer<typeof annotationInputSchema>;
