import { copyFile, mkdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const source = resolve(root, 'node_modules/pdfjs-dist/build/pdf.worker.min.mjs');
const target = resolve(root, 'public/pdf.worker.min.mjs');
try { await mkdir(dirname(target), { recursive: true }); await copyFile(source, target); console.log('Copied PDF.js worker to public/.'); }
catch (error) { console.warn('PDF.js worker copy skipped. Run npm install and retry.'); if (process.env.CI) throw error; }
